package com.tangkapapel.game;

import java.util.Iterator;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;

public class GameScreen implements Screen {
    final TangkapApel game;

    private Texture apel;
    private Texture bucketImage;
    private Texture background;
    private OrthographicCamera camera;
    private Rectangle bucket;
    private Array<Rectangle> apeldrops;
    private long lastDropTime;
    private int dropGathered;

    public GameScreen(final TangkapApel game) {
        this.game = game;
        apel = new Texture(Gdx.files.internal("apel.png"));
        bucketImage = new Texture(Gdx.files.internal("bucket.png"));
        background = new Texture(Gdx.files.internal("background.jpg"));

        camera = new OrthographicCamera();
        camera.setToOrtho(false,800,480);

        bucket = new Rectangle();
        bucket.x = 800/2-64/2;
        bucket.y = 20;
        bucket.width = 64;
        bucket.height = 64;

        apeldrops = new Array<Rectangle>();
        apelDrop();
    }

    private void apelDrop(){
        Rectangle apelDrop = new Rectangle();
        apelDrop.x = MathUtils.random(0,800-64);
        apelDrop.y = 480;
        apelDrop.width = 64;
        apelDrop.height = 64;
        apeldrops.add(apelDrop);
        lastDropTime = TimeUtils.nanoTime();
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0.2f, 1);
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.draw(background, 0, 0, 800, 480);
        game.font.draw(game.batch, "Apel yang dikumpulkan : " + dropGathered, 300, 375);
        game.batch.draw(bucketImage, bucket.x, bucket.y, bucket.width, bucket.height);
        for (Rectangle apelDrop : apeldrops) {
            game.batch.draw(apel, apelDrop.x, apelDrop.y);
        }
        game.batch.end();

        if (Gdx.input.isTouched()) {
            Vector3 touchpos = new Vector3();
            touchpos.set(Gdx.input.getX(), Gdx.input.getY(), 0);
            camera.unproject(touchpos);
            bucket.x = touchpos.x - 64 / 2;
        }
        if (Gdx.input.isKeyPressed(Keys.LEFT))
            bucket.x -= 200 * Gdx.graphics.getDeltaTime();
        if (Gdx.input.isKeyPressed(Keys.RIGHT))
            bucket.x += 200 * Gdx.graphics.getDeltaTime();
        if (Gdx.input.isKeyPressed(Keys.UP))
            bucket.y += 200 * Gdx.graphics.getDeltaTime();
        if (Gdx.input.isKeyPressed(Keys.DOWN))
            bucket.y -= 200 * Gdx.graphics.getDeltaTime();

        if (bucket.x < 0) bucket.x = 0;
        if (bucket.x > 800 - 64) bucket.x = 800 - 64;
        if (bucket.y > 480) bucket.y = 480;
        if (bucket.y < 0) bucket.y = 0;

        if (TimeUtils.nanoTime() - lastDropTime > 1000000000) apelDrop();

        Iterator<Rectangle> iter = apeldrops.iterator();
        while (iter.hasNext()) {
            Rectangle bananaDrop = iter.next();
            bananaDrop.y -= 200 * Gdx.graphics.getDeltaTime();
            if (bananaDrop.y + 64 < 0) iter.remove();
            if (bananaDrop.overlaps(bucket)) {
                dropGathered++;
                iter.remove();
            }
        }

    }
    @Override
    public void resize(int width,int height){}

    @Override
    public void show() {}

    @Override
    public void hide() {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void dispose() {
        apel.dispose();
        bucketImage.dispose();
        background.dispose();
    }
}
